/*******************************************************************************
 * (c) Copyright 2015 Microsemi SoC Products Group.  All rights reserved.
 *
 * This example project demonstrates control  control the duty cycle of
 * individual PWM outputs
 *
 * Please refer to the file README.txt for further details about this example.
 *
 * SVN $Revision: 8042 $
 * SVN $Date: 2015-10-15 17:55:12 +0530 (Thu, 15 Oct 2015) $
 */
#include "platform.h"
#include "core_pwm.h"

/******************************************************************************
 * Delay count used to time the delay between duty cycle updates.
 *****************************************************************************/
#define DELAY_COUNT     100000

/******************************************************************************
 * PWM prescale and period configuration values.
 *****************************************************************************/
#define PWM_PRESCALE    49
#define PWM_PERIOD      399

/******************************************************************************
 * CorePWM instance data.
 *****************************************************************************/
pwm_instance_t the_pwm;

/******************************************************************************
 * Local function prototype.
 *****************************************************************************/
void delay( void );

/******************************************************************************
 * main function.
 *****************************************************************************/
int main( void )
{
    uint32_t duty_cycle = 1;
    int direction = 1;

    /**************************************************************************
     * Initialize the CorePWM instance setting the prescale and period values.
     *************************************************************************/
    PWM_init( &the_pwm, COREPWM_BASE_ADDR, PWM_PRESCALE, PWM_PERIOD ) ;

    /**************************************************************************
     * Set the initial duty cycle for CorePWM output 1.
     *************************************************************************/
    PWM_set_duty_cycle( &the_pwm, PWM_1, duty_cycle );

    /**************************************************************************
     * Enable CorePWM output 2 and set the duty cycle (fixed)
     *************************************************************************/
   PWM_enable( &the_pwm, PWM_2 );
   PWM_set_duty_cycle( &the_pwm, PWM_2, 350 );

    while ( 1 )
    {
        /**********************************************************************
         * Update the duty cycle for CorePWM output 1.
         *********************************************************************/
        PWM_set_duty_cycle( &the_pwm, PWM_1, duty_cycle );
        /**********************************************************************
         * Wait for a short delay.
         *********************************************************************/
        delay();
        /**********************************************************************
         * Calculate the next PWM duty cycle.
         *********************************************************************/
        duty_cycle += direction;
        if ( duty_cycle >= PWM_PERIOD )
        {
            direction = -1;
        }
        else if ( duty_cycle == 0 )
        {
            direction = 1;
        }
    }

}

/******************************************************************************
 * Delay function.
 *****************************************************************************/
void delay( void )
{
    volatile int counter = 0;

    while ( counter < DELAY_COUNT )
    {
        counter++;
    }
}
