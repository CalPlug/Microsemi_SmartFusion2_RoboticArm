#ifndef SF2_MSS_sys_HW_PLATFORM_H_
#define SF2_MSS_sys_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Microsemi SmartDesign  Fri Feb 03 12:32:19 2017
*
*Memory map specification for peripherals in SF2_MSS_sys
*/

/*-----------------------------------------------------------------------------
* CM3 subsystem memory map
* Master(s) for this subsystem: CM3 
*---------------------------------------------------------------------------*/
#define COREPWM_0_0                     0x50000000U


#endif /* SF2_MSS_sys_HW_PLATFORM_H_*/
