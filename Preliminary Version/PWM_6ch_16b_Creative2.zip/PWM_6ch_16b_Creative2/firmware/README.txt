Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v11.7 SP2 (Version 11.7.2.2)

Date    :    Fri Feb 03 12:32:19 2017
Project :    D:\Microsemiprj\UC_Irvine\PWM_6ch_16b_Creative
