/*******************************************************************************
 *Base Example code (c) Copyright 2015 Microsemi SoC Products Group.  All rights reserved.
 *Extended application by Tim McCarthy (Microsemi) and Michael Klopfer (UC Irvine)
 * This example project demonstrates control  control the duty cycle of
 * individual PWM outputs
 *
 * Please refer to the file README.txt for further details about this example.
 *
 * SVN $Revision: 8042 $
 * SVN $Date: 2015-10-15 17:55:12 +0530 (Thu, 15 Oct 2015) $
 */
#include "platform.h"
#include "core_pwm.h"
#include <stdio.h>  //added by Tim McCarthy for Semihosting (Console Debug)

#define VERBOSEDEBUGCONSOLE //Verbose debugging in console using Semihosting, comment out to disable console debug messages - do not go too crazy with semihosting, it will slow down operation if used excessively
#define MOTIONONE// A to B
#define MOTIONTWO// B to A
#define MOTIONTHREE// C to D
#define MOTIONFOUR// D to C
#define MOTIONFIVE //Agitate A
//#define MOTIONSIX // Agitate B
#define MOTIONSEVEN// Agitate C
//#define MOTIONEIGHT// Agitate D
//#define MOTIONNINE//DemoMotions
/******************************************************************************
 * Delay count used to time the delay between duty cycle updates.  (Unless fabric is changed please do not modify, unless you have an exceedingly good reason to do so)
 *****************************************************************************/
#define DELAY_COUNT     6500  //principle multiplier to set delays in function (changing this changes the length of all delays, modify with caution, should be set so a delay of 1000=1s)

/******************************************************************************
 * PWM prescale and period configuration values.  (Unless fabric is changed please do not modify, unless you have an exceedingly good reason to do so)
 *****************************************************************************/
#define PWM_PRESCALE    49  //Prescale value 4 (formerly set to 39)
#define PWM_PERIOD      399  //full period     (formerly set to 499)

/******************************************************************************
 * Servo Global Operation Parameters  (Project global settings - modify with justification and caution!)
 *****************************************************************************/
#define MAX_DEFLECT 52.0 //max deflection of servo (pwm value) (use whole number with decimal for float calc)
#define MIN_DEFLECT 6.0 //min deflection of servo (pwm value) (use whole number with decimal for float calc)
#define ROTATION_DEGREES 170.0 //Servo physical rotation span (degrees) (use whole number with decimal for float calc)

/******************************************************************************
 * Servo Trim Parameters - Trim Parameters for each servo to correct differences between units for identical performance
 *****************************************************************************/
#define TRIM_ROT_DEG_GAIN_1 1.0
#define TRIM_ROT_DEG_OFFSET_1 0.0
#define TRIM_MIN_1_PWM 6.0
#define TRIM_MAX_1_PWM -8.0

#define TRIM_ROT_DEG_GAIN_2 1.0
#define TRIM_ROT_DEG_OFFSET_2 0.0
#define TRIM_MIN_2_PWM 6.0
#define TRIM_MAX_2_PWM -8.0

#define TRIM_ROT_DEG_GAIN_3 1.0
#define TRIM_ROT_DEG_OFFSET_3 0.0
#define TRIM_MIN_3_PWM 2.0
#define TRIM_MAX_3_PWM -8.0

#define TRIM_ROT_DEG_GAIN_4 1.0
#define TRIM_ROT_DEG_OFFSET_4 0.0
#define TRIM_MIN_4_PWM 6.0
#define TRIM_MAX_4_PWM -8.0

#define TRIM_ROT_DEG_GAIN_5 1.0
#define TRIM_ROT_DEG_OFFSET_5 0.0
#define TRIM_MIN_5_PWM 3.0
#define TRIM_MAX_5_PWM -8.0

#define TRIM_ROT_DEG_GAIN_6 1.0
#define TRIM_ROT_DEG_OFFSET_6 0.0
#define TRIM_MIN_6_PWM 5.0
#define TRIM_MAX_6_PWM -8.0

#define TRIM_ROT_DEG_GAIN_7 1.0
#define TRIM_ROT_DEG_OFFSET_7 0.0
#define TRIM_MIN_7_PWM 6.0
#define TRIM_MAX_7_PWM -8.0

#define TRIM_ROT_DEG_GAIN_8 1.0
#define TRIM_ROT_DEG_OFFSET_8 0.0
#define TRIM_MIN_8_PWM 6.0
#define TRIM_MAX_8_PWM -8.0
/******************************************************************************
//Servo Names mapping to PWM Output
 ******************************************************************************/
#define JAW 6  //Pincher Jaws (Creative Board - Pin D5)
#define JAWROT 5 //Rotation of the Jaws  (Creative Board - Pin D4)
#define JAWPIVOT 4 //Pivot of Jaws  (Creative Board - Pin D9)
#define ARMEXT 3 //Extension of arm  (Creative Board - Pin D8)
#define ARMROT 2 //Rotation of arm base  (Creative Board - D10)
#define DIAGLED 1 //Diagnostic LED  (Creative Board - LED1 Green)
#define AUX0 7 //Aux channel 0  (Creative Board - (die P12))
#define AUX1 8 //Aux channel 0  (Creative Board - (die P13))



/******************************************************************************
 * CorePWM instance data.
 *****************************************************************************/
pwm_instance_t the_pwm;

/******************************************************************************
 * Local function prototype.
 *****************************************************************************/
void delay( int mult );
float set_deg_inc(float deg_new, float deg_old, int dir, float stepsize, int delay_len, int servo_num);
void set_deg_abs(float deg, int pwmnum);
void motionextremes();
void grabtube(int pos);
void motiononeHoldtoA();
void returntohold();
void demomotions();
void motiononeAtoB();
void motiononeBtoHold();
void motiononebheighttransition();
void motiontwoHoldtoB();
void motiontwoBtoA();
void motionotwoaheighttransition();
void motiontwoAtoHold();
void motionthreeHoldtoC();
void motionsevenCtoagitate();
void motionsevenCtoHold();
void motionthreeCtoD();
void motionthreeDtoHold();
void motionfourHoldtoD();
void motionfourDtoC();
void motionfourCtoHold();
void putdownC();
void motionfourCheighttransition();
void motionfiveAtoagitate();
void putdownA();
void Demo();
void AtoB();
void BtoA();
void CtoD();
void DtoC();
void AgitateA();
void AgitateC();

/******************************************************************************
 * Function prototype for Semihosting - added Tim McCarthy
 *****************************************************************************/
extern void initialise_monitor_handles(void);

/******************************************************************************
 * main function.
 *****************************************************************************/
int main( void )
{
uint32_t duty_cycle = 1;  //Set PWM initial duty cycle
#ifdef VERBOSEDEBUGCONSOLE
   	   /******************************************************************************
        * Write a message to the SoftConsole host via OpenOCD and the debugger - added TM
        *****************************************************************************/
   	    initialise_monitor_handles();
   	    iprintf("Debug messages via ARM Semihosting initialized\n");
#endif

    /**************************************************************************
     * Initialize the CorePWM instance setting the prescale and period values.
     *************************************************************************/
    PWM_init( &the_pwm, COREPWM_BASE_ADDR, PWM_PRESCALE, PWM_PERIOD ) ;

    /**************************************************************************
     * Set the initial duty cycle for CorePWM output 1.
     *************************************************************************/

    //Initialize into save SERVO DOF holding positions:
    //Initial position
    	set_deg_abs(100.0, JAW);  //Send JAW (JAW CLOSURE POSITION) to INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(130.0, JAWPIVOT);  //Send JAWPIVOT (JAW PIVOTING)to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(30.0, JAWROT);  //Send JAWROT (JAW ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(90.0, ARMROT);  //Send ARMROT (ARM ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(35.0, ARMEXT);  //Send JAWPIVOT to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(90.0, AUX0);  //Set AUX0 to 100 - just a number to initialize, no use at this point
    	set_deg_abs(25.0, AUX1);  //Set AUX1 to 100 - just a number to initialize, no use at this point
    	delay (2000);//Pause at initial HOLD position before setting final hold position

    	//Initial HOLD Point
    	set_deg_abs(110.0, JAW);  //Send JAW (JAW CLOSURE POSITION) to INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(160.0, JAWPIVOT);  //Send JAWPIVOT (JAW PIVOTING)to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(38.0, JAWROT);  //Send JAWROT (JAW ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(92.0, ARMROT);  //Send ARMROT (ARM ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(30.0, ARMEXT);  //Send JAWPIVOT to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(100.0, AUX0);  //Set AUX0 to 100 - just a number to initialize, no use at this point
    	set_deg_abs(100.0, AUX1);  //Set AUX1 to 100 - just a number to initialize, no use at this point
    	delay (500);//Pause at final HOLD position then run initialization a third time to make sure PWMs set properly for first run (then run initialization a second time to make sure PWMs set properly for first run)

    	//Initial HOLD Point
    	set_deg_abs(110.0, JAW);  //Send JAW (JAW CLOSURE POSITION) to INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(160.0, JAWPIVOT);  //Send JAWPIVOT (JAW PIVOTING)to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(38.0, JAWROT);  //Send JAWROT (JAW ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(92.0, ARMROT);  //Send ARMROT (ARM ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(30.0, ARMEXT);  //Send JAWPIVOT to an INTERMEDIATE position using incremental motion for safe holding
    	set_deg_abs(100.0, AUX0);  //Set AUX0 to 100 - just a number to initialize, no use at this point
    	set_deg_abs(100.0, AUX1);  //Set AUX1 to 100 - just a number to initialize, no use at this point


//For Quick Reference:
     // JAW 6  //Pincher jaws (Creative Board - Pin D5)
     // JAWROT 5 //Rotation of the jaws  (Creative Board - Pin D4)
     // JAWPIVOT 4 //Pivot of jaws  (Creative Board - Pin D9)
     // ARMEXT 3 //Extension of arm  (Creative Board - Pin D8)
     // ARMROT 2 //Rotation of arm base  (Creative Board - D10)
     // DIAGLED 1 //AUX Channel, Diagnostic LED  (Creative Board - LED1 Green)
     // AUX0 7 //Aux channel 0  (Creative Board - (die P12))
     // AUX1 8 //Aux channel 0  (Creative Board - (die P13))

#ifdef VERBOSEDEBUGCONSOLE
        iprintf("Complete PWM Initialization and initial position start\n");
#endif
    	delay (4000); //Pause at HOLD position then continue operation

while ( 1 ) //Infinite loop for demo motions of servos  (For testing the code is placed in here to check repeatability)
	{


/******************************************************************************
 *************************************************************************/
#ifdef MOTIONDEMOS
//Motion Demos
	//Function is a demo to move between extremes of motion on each DoF for the arm sequentially
		motionextremes(); //demo motion for DoF extremes  (function written

    //Function to demo motion of arm as a continuously running demo (motion with more "sense of purpose" and smoother than DoF Demo)
		demomotions(); //demo motion (needs to be written)
#endif

#ifdef MOTIONONE
	//Motion "one" to bring arm from hold to pick up tube in position A, then place in position b, then release tube in position b and return arm to HOLD
		//Example of how this works:

		AtoB();
		//then pick up tube, bring to position B, then release and return to hold, continue with similar function, driven structure
#endif

#ifdef MOTIONTWO
    //Motion "two" to bring arm from hold to pick up tube in position B, then place in position A, then release tube in position A and return arm to HOLD

		BtoA();
#endif

#ifdef MOTIONTHREE
		//Motion "three" to bring arm from hold to pick up tube in position C, then place in position D, then release tube in position C and return arm to HOLD
		CtoD();
#endif


#ifdef MOTIONFOUR
	//Motion "four" to bring arm from hold to pick up tube in position C, then place in position D, then release tube in position C and return arm to HOLD
		DtoC();

#endif
//Tube Invert demos
   //Motion "five" - Pick up tube in position A, rotate tube (rock side to side), flip back, then return to position A (this is a demo simulation of mixing, there will be glitter solution inside tube)
#ifdef MOTIONFIVE
		AgitateA();

#endif


   //Motion "seven" - Pick up tube in position C, rotate tube, flip back (rock side to side), then return to position C (this is a demo simulation of mixing, there will be glitter solution inside tube)
#ifdef MOTIONSEVEN
		AgitateC();
#endif

#ifdef MOTIONNINE
		Demo();
#endif



	#ifdef VERBOSEDEBUGCONSOLE
        iprintf("loop completed\n");
	#endif
    delay (500); //delay before recycling loop
	}

}



/******************************************************************************
 * Delay function.
 *****************************************************************************/
void delay( int mult )
{
    volatile int counter = 0;

    while ( counter < (DELAY_COUNT*mult) )
    {
        counter++;
    }
}


/******************************************************************************
 * ABS Motion Function.
 *****************************************************************************/

void set_deg_abs(float deg, int pwmnum)
{
	    float deg_position_duty;

		//Drive Servo with PWM value after calculation with requested degree and trim parameters for each servo
		if (pwmnum==1)
		{
			deg_position_duty=((((MAX_DEFLECT+TRIM_MAX_1_PWM)-(MIN_DEFLECT+TRIM_MIN_1_PWM))/(ROTATION_DEGREES))*(((TRIM_ROT_DEG_GAIN_1)*deg)+TRIM_ROT_DEG_OFFSET_1))+(MIN_DEFLECT+TRIM_MIN_1_PWM);
			PWM_set_duty_cycle( &the_pwm, PWM_1, (int)deg_position_duty);//Set position of servo 1
		}

		else if (pwmnum==2)
		{
			deg_position_duty=((((MAX_DEFLECT+TRIM_MAX_2_PWM)-(MIN_DEFLECT+TRIM_MIN_2_PWM))/(ROTATION_DEGREES))*(((TRIM_ROT_DEG_GAIN_2)*deg)+TRIM_ROT_DEG_OFFSET_2))+(MIN_DEFLECT+TRIM_MIN_2_PWM);
			PWM_set_duty_cycle( &the_pwm, PWM_2, (int)deg_position_duty);//Set position of servo 2
		}

		else if (pwmnum==3)
		{
			deg_position_duty=((((MAX_DEFLECT+TRIM_MAX_3_PWM)-(MIN_DEFLECT+TRIM_MIN_3_PWM))/(ROTATION_DEGREES))*(((TRIM_ROT_DEG_GAIN_3)*deg)+TRIM_ROT_DEG_OFFSET_3))+(MIN_DEFLECT+TRIM_MIN_3_PWM);
			PWM_set_duty_cycle( &the_pwm, PWM_3, (int)deg_position_duty);//Set position of servo 3
		}

		else if (pwmnum==4)
		{
			deg_position_duty=((((MAX_DEFLECT+TRIM_MAX_4_PWM)-(MIN_DEFLECT+TRIM_MIN_4_PWM))/(ROTATION_DEGREES))*(((TRIM_ROT_DEG_GAIN_4)*deg)+TRIM_ROT_DEG_OFFSET_4))+(MIN_DEFLECT+TRIM_MIN_4_PWM);
			PWM_set_duty_cycle( &the_pwm, PWM_4, (int)deg_position_duty);//Set position of servo 4
		}

		else if (pwmnum==5)
		{
			deg_position_duty=((((MAX_DEFLECT+TRIM_MAX_5_PWM)-(MIN_DEFLECT+TRIM_MIN_5_PWM))/(ROTATION_DEGREES))*(((TRIM_ROT_DEG_GAIN_5)*deg)+TRIM_ROT_DEG_OFFSET_5))+(MIN_DEFLECT+TRIM_MIN_5_PWM);
			PWM_set_duty_cycle( &the_pwm, PWM_5, (int)deg_position_duty);//Set position of servo 5
		}

		else if (pwmnum==6)
		{
			deg_position_duty=((((MAX_DEFLECT+TRIM_MAX_6_PWM)-(MIN_DEFLECT+TRIM_MIN_6_PWM))/(ROTATION_DEGREES))*(((TRIM_ROT_DEG_GAIN_6)*deg)+TRIM_ROT_DEG_OFFSET_6))+(MIN_DEFLECT+TRIM_MIN_6_PWM);
			PWM_set_duty_cycle( &the_pwm, PWM_6, (int)deg_position_duty);//Set position of servo 6
		}
		else if (pwmnum==6)
		{
			deg_position_duty=((((MAX_DEFLECT+TRIM_MAX_7_PWM)-(MIN_DEFLECT+TRIM_MIN_7_PWM))/(ROTATION_DEGREES))*(((TRIM_ROT_DEG_GAIN_7)*deg)+TRIM_ROT_DEG_OFFSET_7))+(MIN_DEFLECT+TRIM_MIN_7_PWM);
			PWM_set_duty_cycle( &the_pwm, PWM_7, (int)deg_position_duty);//Set position of servo 7
		}
		else if (pwmnum==6)
		{
			deg_position_duty=((((MAX_DEFLECT+TRIM_MAX_8_PWM)-(MIN_DEFLECT+TRIM_MIN_8_PWM))/(ROTATION_DEGREES))*(((TRIM_ROT_DEG_GAIN_8)*deg)+TRIM_ROT_DEG_OFFSET_8))+(MIN_DEFLECT+TRIM_MIN_8_PWM);
			PWM_set_duty_cycle( &the_pwm, PWM_8, (int)deg_position_duty);//Set position of servo 8
		}
		else
		{}  //end if statement

}
/******************************************************************************
	Return to Hold Function
 *****************************************************************************/
void returntohold()
	{
	set_deg_abs(110.0, JAW);  //Send JAW (JAW CLOSURE POSITION) to INTERMEDIATE position using incremental motion for safe holding
	set_deg_abs(160.0, JAWPIVOT);  //Send JAWPIVOT (JAW PIVOTING)to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_abs(38.0, JAWROT);  //Send JAWROT (JAW ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_abs(92.0, ARMROT);  //Send ARMROT (ARM ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_abs(30.0, ARMEXT);  //Send JAWPIVOT to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_abs(100.0, AUX0);  //Set AUX0 to 100 - just a number to initialize, no use at this point
	set_deg_abs(100.0, AUX1);  //Set AUX1 to 100 - just a number to initialize, no use at this point

#ifdef VERBOSEDEBUGCONSOLE
   	   /******************************************************************************
        * Write a message to the SoftConsole host via OpenOCD and the debugger - added TM
        *****************************************************************************/
   	    initialise_monitor_handles();
   	    iprintf("Set to HOLD Point\n");
#endif
	}

/******************************************************************************
	Grabbing Tubes Functions
 *****************************************************************************/
void grabtube(int pos) //set position of jaws for grabbing objects - because of the short distance this is simply implemented in absolute motion, this will not work for all drive motions!
{
	if (pos==0)
		{
		set_deg_abs(120.0, JAW); //safe resting position (nearly full closed)
		}
	else if (pos==1)
		{
		set_deg_abs(130.0, JAW);//Jaws full closed (this is with small continued force, do not leave in this position grabbing tube for more than aprox 15 sec. because servo will heat up!)
		}

	else if (pos==2)
		{
		set_deg_abs(50.0, JAW); //Open jaws (release tube)
		}
	else if (pos==3)
		{
			set_deg_abs(110.0, JAW);//Jaws to grab conical plastic tube  (release tube)
		}
	else
	{} //end of IF statements
	delay (50);
}


/******************************************************************************
	Demo motions
 *****************************************************************************/

void demomotions()
{
	//Demonstration motion program to have as a demo for general motion, will return to HOLD between cycles
}


float set_deg_inc(float deg_new, float deg_old, int dir, float stepsize, int delay_len, int servo_num)
{
	float holder;
	if (dir==1)
	{
	for (float i = deg_old; i <= (float)deg_new; i = (float)i + (float)stepsize)
		{
		set_deg_abs(i, servo_num);
		delay(delay_len);
		holder=i;
		}
	}
	else if (dir==0)
	{
		for (float i = deg_old; i >= (float)deg_new; i = (float)i - (float)stepsize)
			{
			set_deg_abs(i, servo_num);
			delay(delay_len);
			holder=i;
			}
	}
	return holder; //keep track of position to prevent loss of location
}
/******************************************************************************
	Motion One
 *****************************************************************************/
void motiononeHoldtoA ()
{

		set_deg_inc(115.0,92.0,1,.25,10,ARMROT); //pivot arm from hold to Point A
		delay(1000);
		set_deg_inc(92.0,30.0,1,1,10,ARMEXT); //brings arm down to test tube
		delay(1000);
		set_deg_inc(84.0,160.0,0,1,10,JAWPIVOT); //adjusting jaw down
		delay(1000);
		grabtube (3);
		delay(500);
		set_deg_inc(75.0, 84.0, 1 ,0.5,10,JAWPIVOT); //adjusting jaw down
		delay(300);
		set_deg_inc(60.0, 93.0, 0, 1, 10, ARMEXT); // moves arm up to lift test tube
		delay(1000);
}


void motiononeAtoB(){

	set_deg_inc(63.0, 115.0, 0, .5, 5, ARMROT); //rotate arm from point A to point B
	delay(1000);
	set_deg_inc(55.0, 38.0, 1, 1, 10, JAWROT);  //Send JAWROT (JAW ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
	delay(500);
	set_deg_inc(74.0, 75.0, 0, 1, 10, JAWPIVOT); // moves jaw down to align tube to hole B
	delay(1000);
	set_deg_inc(78.0, 60.0, 1, 1, 10, ARMEXT); //placing tube into position B
	delay (500);
}


void motiononebheighttransition()
{

	set_deg_inc(50.0, 90.0, 0, 1, 10, ARMEXT); // move arm up after dropping tube to hole B
	delay(500);
	set_deg_inc(38.0, 55.0, 0, 1, 10, JAWROT);  //Send JAWROT (JAW ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
	delay (1000);
}

void motiononeBtoHold()
{
	set_deg_inc(110.0, 110.0, 1, 1, 10, JAW);  //Send JAW (JAW CLOSURE POSITION) to INTERMEDIATE position using incremental motion for safe holding
	set_deg_inc(160.0, 74.0, 1, 1, 10, JAWPIVOT);  //Send JAWPIVOT (JAW PIVOTING)to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_inc(38.0, 38.0, 1, 1, 10, JAWROT);  //Send JAWROT (JAW ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_inc(91.5, 64.0, 1, .5, 10, ARMROT);  //Send ARMROT (ARM ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_inc(30.0, 50.0, 0, 1, 10, ARMEXT);  //Send JAWPIVOT to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_abs(100.0, AUX0);  //Set AUX0 to 100 - just a number to initialize, no use at this point
	set_deg_abs(100.0, AUX1);  //Set AUX1 to 100 - just a number to initialize, no use at this point
	delay(500);
}

/******************************************************************************
	Motion Two
 *****************************************************************************/
void motiontwoHoldtoB()
{

	set_deg_inc(64.0, 91.5, 0, .5 , 10, ARMROT); //pivot arm from hold to Point B
	delay(1000);
	set_deg_inc(108.0, 30.0, 1, 1, 10, ARMEXT); //bring arm down to tube at Point B
	delay(1000);
	set_deg_inc(96.0 , 160.0, 0, .5, 10, JAWPIVOT); //adjust jaw down
	delay(1000);
	grabtube(3);
	delay(500);
	set_deg_inc(94.0, 96.0, 0, 1, 10, JAWPIVOT); //adjust jaw down
	delay(1000);
	set_deg_inc(70.0, 110.0, 0, 1, 10, ARMEXT); //moves arm to lift tube
	delay(1000);
}

void motiontwoBtoA()
{

	set_deg_inc(112.0, 63.5, 1, .5, 5, ARMROT);
	delay(1000);
	set_deg_inc(28.0,38.0, 0, 1, 10, JAWROT); //rotates jaw to align into hole A
	delay(500);
	set_deg_inc(88.0, 94.0, 0, 1, 10, JAWPIVOT); //moves jaw down to align tube to hole A
	delay(500);
	set_deg_inc(87.0, 70.0, 1, 1, 10, ARMEXT); //place tube in point A
	delay(1000);
	set_deg_inc(78.0, 88.0, 0, 1, 10, JAWPIVOT); //moves jaw down to align tube to hole A
	delay(500);

}

void motionotwoaheighttransition()
{
	set_deg_inc(50.0, 87.0, 0, 1, 10, ARMEXT); // move arm up after dropping tube to hole A
	delay(500);
}

void motiontwoAtoHold()
{
	set_deg_inc(110.0, 110.0, 1, 1, 10, JAW);  //Send JAW (JAW CLOSURE POSITION) to INTERMEDIATE position using incremental motion for safe holding
	set_deg_inc(160.0, 83.0, 1, 1, 10, JAWPIVOT);  //Send JAWPIVOT (JAW PIVOTING)to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_inc(38.0, 28.0, 0, 1, 10, JAWROT);  //Send JAWROT (JAW ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_inc(92.0, 112.0, 1, .5, 10, ARMROT);  //Send ARMROT (ARM ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_inc(30.0, 50.0, 0, 1, 10, ARMEXT);  //Send JAWPIVOT to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_abs(100.0, AUX0);  //Set AUX0 to 100 - just a number to initialize, no use at this point
	set_deg_abs(100.0, AUX1);  //Set AUX1 to 100 - just a number to initialize, no use at this point
	delay(500);
}

/******************************************************************************
	Motion Three
 *****************************************************************************/

void motionthreeHoldtoC() //Hold to C
{

    set_deg_inc(85.0,92.0,0,.5,10,ARMROT); //pivot arm from hold to Point C
    delay(600);
    set_deg_inc(103,30.0,1,0.5,10,ARMEXT); //brings arm down to test tube
    delay(300);
    set_deg_inc(92.0,160.0,0,0.5,10,JAWPIVOT); //adjusting jaw down
    delay(300);
	grabtube(3);
	delay(500);
	set_deg_inc(88.0, 92.0,0,0.5,10,JAWPIVOT);
	delay(300);
	set_deg_inc(75.0, 103.0, 0, 1, 15, ARMEXT); //moves arm to lift tube
	delay(1000);
}


void motionthreeCtoD()
{
	set_deg_inc(53.0, 85.0, 0, 1, 10, ARMROT);
	delay(500);
	set_deg_inc(80.0, 88.0, 0, 1, 10, JAWPIVOT);
	delay(1000);
	set_deg_inc(42.0, 38.0, 1, 1, 10, JAWROT);
	set_deg_inc(87.0, 75.0, 1, 1, 10, ARMEXT);
	delay(500);

}
void motionthreeDtoHold()
{
	set_deg_inc(30.0, 87.0, 0, 1, 10, ARMEXT);
	set_deg_inc(160.0, 80.0, 1, 1, 10, JAWPIVOT);  //Send JAWPIVOT (JAW PIVOTING)to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_inc(38.0, 42.0, 0, 1, 10, JAWROT);  //Send JAWROT (JAW ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
	set_deg_inc(92.0, 53.0, 1, 1, 10, ARMROT);  //Send ARMROT (ARM ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
	delay(500);
}

/******************************************************************************
	Motion Four // Tube D to C
 *****************************************************************************/

void motionfourHoldtoD()
{
	set_deg_inc(53.0, 92.0, 0, 1, 10, ARMROT);
	delay(500);
	set_deg_inc(80.0, 160.0, 0, 1, 10, JAWPIVOT);
	delay(1000);
	set_deg_inc(90.0, 30.0, 1, 1, 10, ARMEXT);
	delay(500);
	grabtube(3);
	delay(500);
	set_deg_inc(75.0, 80.0,0,1,10,JAWPIVOT); //adjusting tube within hole
	delay(500);
	set_deg_inc(70.0, 90.0, 0, 1, 10, ARMEXT); //lifting tube out of hole
	delay(1000);

}

void motionfourDtoC()
{
	set_deg_inc(90.0, 53.0, 1, 1, 10, ARMROT); // move tube from D to C
	delay(2000);
	set_deg_inc(55.0, 38.0, 1, 1, 10, JAWROT); // Align tube to D
	delay(1000);
	set_deg_inc(73.0, 75.0, 0, 1, 10, JAWPIVOT); // Aligns tube to D
	delay(1000);
	set_deg_inc(84.0, 70.0, 1, 1, 10, ARMEXT); //puts tube into C
	delay(500);

}


void motionfourCheighttransition()
{

	set_deg_inc(87.0, 84.0, 1, 1, 10, ARMEXT); // move arm down wiggle off tube
	delay(500);
	set_deg_inc(91.0, 90.0, 1, .5, 5, ARMROT); //rotate arm from point A to point B
	delay(200);
}
void motionfourCtoHold()
{
	set_deg_inc(38.0, 55.0, 0, 1, 10, JAWROT);
	set_deg_inc(160.0, 73.0,1,1,10,JAWPIVOT); //adjusting tube within hole
	delay(500);
	set_deg_inc(30.0, 87.0, 0, 1, 10, ARMEXT); //lifting tube out of hole
	delay(500);
	set_deg_inc(92.0, 91.0, 1, 1, 10, ARMROT); // move tube from D to C
	delay(1000);

}


/******************************************************************************
	Motion Five
 *****************************************************************************/
void motionfiveAtoagitate()
{

		set_deg_inc(115.0, 75.0, 1, 0.5, 10, JAWPIVOT);
		set_deg_inc(180.0, 38.0, 1, 1, 5, JAWROT); //rotate tube
        delay(600);
        set_deg_inc(5.0, 180.0, 0, 1, 5, JAWROT); //rotate tube back
        delay(500);
        set_deg_inc(180.0, 5.0, 1, 1, 5, JAWROT);
        delay(500);
        set_deg_inc(38.0, 180.0, 0, 1, 5, JAWROT);
        delay(600);

}
void putdownA()
{

		set_deg_inc(30.0 ,38.0, 0, 1, 10, JAWROT); //rotates jaw to align into hole A
		delay(500);
		set_deg_inc(90.0, 115.0, 0, 1, 10, JAWPIVOT); //moves jaw down to align tube to hole A
		delay(1000);
		set_deg_inc(85.0, 60.0, 1, 1, 10, ARMEXT); //place tube in point A
		delay(1500);
		set_deg_inc(83.0, 90.0, 0, 1, 10, JAWPIVOT); //moves jaw down to align tube to hole A
		delay(500);
		grabtube(2);
		delay(500);
		set_deg_inc(50.0, 85.0, 0, 1, 10, ARMEXT); // move arm up after dropping tube to hole A
		delay(1000);
		set_deg_inc(83.0, 83.0, 1, 1, 10, JAWPIVOT);  //adjusted for INTERMEDIATE position using incremental motion for safe holding
		delay(500);
}

/******************************************************************************
	Motion Six
 *****************************************************************************/

/******************************************************************************
	Motion Seven //C to agitate
 *****************************************************************************/

void motionsevenCtoagitate()
{
		set_deg_inc(120.0,88.0,1,1,10,JAWPIVOT);
        set_deg_inc(180.0, 38.0, 1, 1, 5, JAWROT); //rotate tube
        delay(600);
        set_deg_inc(5.0, 180.0, 0, 1, 5, JAWROT); //rotate tube back
        delay(500);
        set_deg_inc(180.0, 5.0, 1, 1, 5, JAWROT);
        delay(500);
        set_deg_inc(38.0, 180.0, 0, 1, 5, JAWROT);
        delay(600);


}
void putdownC()
{

		set_deg_inc(89.0 ,120.0, 0, 1, 10, JAWPIVOT); //adjust jaw pivot
		delay(500);
        set_deg_inc(85.0, 75.0, 1, 1, 15, ARMEXT); //place tube back in C
        delay(1000);
        grabtube(2);
        delay(500);
        set_deg_inc(88.0, 85.0, 1, 1, 10, ARMEXT); // move arm down wiggle off tube
        delay(500);
        set_deg_inc(86.0, 85.0, 1, .5, 5, ARMROT); //rotate arm from point A to point B
        delay(200);
}
void motionsevenCtoHold()
{
       //set_deg_inc(110.0, 55.0, 1, 1, 10, JAW);  //Send JAW (JAW CLOSURE POSITION) to INTERMEDIATE position using incremental motion for safe holding
        set_deg_inc(160.0, 89.0, 1, 1, 10, JAWPIVOT);  //Send JAWPIVOT (JAW PIVOTING)to an INTERMEDIATE position using incremental motion for safe holding
        //set_deg_inc(38.0, 38.0, 1, 1, 10, JAWROT);  //Send JAWROT (JAW ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
        //set_deg_inc(92.0, 80.0, 1, 1, 10, ARMROT);  //Send ARMROT (ARM ROTATION) to an INTERMEDIATE position using incremental motion for safe holding
        set_deg_inc(30.0, 88.0, 0, 1, 10, ARMEXT);  //Send JAWPIVOT to an INTERMEDIATE position using incremental motion for safe holding
        set_deg_abs(100.0, AUX0);  //Set AUX0 to 100 - just a number to initialize, no use at this point
        set_deg_abs(100.0, AUX1);  //Set AUX1 to 100 - just a number to initialize, no use at this point
        delay(500);
}


void Demo()
{
	set_deg_abs(110.0, JAW);  //Send JAW (JAW CLOSURE POSITION) to INTERMEDIATE position using incremental motion for safe holding

	    set_deg_inc(50.0,160.0,0,1,5,JAWPIVOT); //move from hold
	    set_deg_inc(100.0,92.0, 1 , 1, 10,ARMROT);//move from hold
	    set_deg_inc(190.0,38.0,1,1,5,JAWROT);//move from hold
	    grabtube(2);
	    delay(200);
		set_deg_inc(160.0,100.0,1,1,10,ARMROT);  //Send ARM ROTATION to new position
		set_deg_inc(80.0,30.0,1,1,8,ARMEXT);  //Send ARMEXT to new position
		set_deg_inc(120.0,50.0,1,1,5,JAWPIVOT);  //Send JAW PIVOT to new position
		delay (200);
		grabtube(3);
		set_deg_inc(0.0,190.0,1,1,5,JAWROT);  //Send JAW ROTATION to extreme position using incremental motion algorithm
		delay (200);
		set_deg_inc(190.0,0.0,0,1,5,JAWROT);  //Send JAW ROTATION to extreme position using incremental motion algorithm
		delay (200);
		set_deg_inc(30.0,80.0,0,1,8 ,ARMEXT);  //Send ARM to extreme position using incremental motion algorithm, this second step is used to prevent arm falling over apex of motion
		set_deg_inc(150.0,120.0,0,1,5,JAWPIVOT);  //Send JAW PIVOT to extreme position using incremental motion algorithm
		grabtube(2);
		delay (200);
		set_deg_inc(0.0,160.0,0,1,10,ARMROT);  //Send ARM ROTATION to extreme position using incremental motion algorithm
		delay (200);
		grabtube(3);
		set_deg_inc(190.0,0.0,1,1,5,JAWROT);  //Send JAW ROTATION to extreme position using incremental motion algorithm
		delay (200);
		set_deg_inc(0.0,190.0,0,1,5,JAWROT);  //Send JAW ROTATION to extreme position using incremental motion algorithm
		delay (200);
		grabtube(2);
		set_deg_inc(160.0, 150.0,1,1,5,JAWPIVOT); //back to holds
		set_deg_inc(38.0,0.0,0,1,5,JAWROT);//back to holds
		set_deg_inc(92.0,0.0,1,1,10,ARMROT);//back to holds
		returntohold();
		delay(1000);

}

void AtoB()
{
	returntohold(); //careful, this can be fast! place arm in the HOLD position if not there already, it should be there, this is really a redundant safety check
	grabtube (2);	//Open jaws to accept tube (pos=0 safe resting position, pos=1 full closed(caution!!), pos=3 open jaws, pos=4 grab conical tube)
	delay (500);
	motiononeHoldtoA();  //  move the arm from the hold position to position A and pick up tube
	delay (500);
	motiononeAtoB(); // move the arm from position A to position B and drop into B
	delay(1000);
	grabtube (2);
	delay (1000);
	motiononebheighttransition(); // move arm up after dropping tube to hole B
	motiononeBtoHold(); //incremental movement to hold position
	delay(200);
	returntohold(); // make sure its in hold
	delay(500);
	returntohold();
	delay (1000);
}

void BtoA()
{
	returntohold(); //careful, this can be fast! place arm in the HOLD position if not there already, it should be there, this is really a redundant safety check
	grabtube (2);	//Open jaws to accept tube (pos=0 safe resting position, pos=1 full closed(caution!!), pos=3 open jaws, pos=4 grab conical tube)
	delay (1000);
	motiontwoHoldtoB(); //move arm from hold position to hole B
	delay(500);
	motiontwoBtoA(); //Move arm from position B to A
	delay(1000);
	grabtube (2); // Open jaws to drop tube into A
	delay(1000);
	motionotwoaheighttransition(); // move arm up after dropping tube to hole A
	motiontwoAtoHold(); //incremental movement to hold position
	delay(200);
	returntohold();
	delay(500);
	returntohold();
	delay (1000);
}

void CtoD()
{
	grabtube(2);
	motionthreeHoldtoC();
	delay(500);
	motionthreeCtoD();
	delay(500);
	grabtube(2);
	delay(500);
	motionthreeDtoHold();
	delay(500);
	returntohold();
	delay(1000);

}

void DtoC()
{
	grabtube(2);
	motionfourHoldtoD();
	delay(500);
	motionfourDtoC();
	delay(500);
	grabtube(2);
	delay(1000);
	motionfourCheighttransition();
	delay(500);
	motionfourCtoHold();
	delay(500);
	returntohold();
	delay(1000);
}

void AgitateA()
{
	grabtube(2);
	motiononeHoldtoA();
	delay(1000);
	motionfiveAtoagitate();
	delay(500);
	putdownA();
	delay(1000);
	motiontwoAtoHold();
	delay(1000);
	returntohold();
	delay(1000);
}

void AgitateC()
{
	grabtube(2);
	motionthreeHoldtoC();
	delay(1000);
	motionsevenCtoagitate ();
	delay(500);
	putdownC();
	delay(1000);
	motionsevenCtoHold();
	returntohold();
	delay(1000);
}
/******************************************************************************
	Motion Extremes
 *****************************************************************************/
void motionextremes()
	{
	//SERVO DOF holding positions:

	//Demo Limit Sweep for each arm degree of Freedom (DOF)

	//JAW MOTION
		set_deg_inc(134.0,50.0,1,1,3,JAW);  //Send JAW to FULL CLOSED position using incremental motion algorithm (positive direction)
		delay (200);
		set_deg_inc(50.0,134.0,0,1,3,JAW);  //Send JAW to FULL OPEN position using incremental motion algorithm (negative direction)
		delay (200);
		set_deg_abs(110, JAW);//Return to safe hold
		delay (200);

	//JAW PIVOT MOTION
		set_deg_inc(179.0,8.0,1,1,5,JAWPIVOT);  //Send JAW PIVOT to extreme position using incremental motion algorithm
		delay (200);
		set_deg_inc(8.0,179.0,0,1,5,JAWPIVOT);  //Send JAW PIVOT to extreme position using incremental motion algorithm
		delay (200);
		set_deg_abs(160, JAWPIVOT); //Return to safe hold
		delay (200);

  //JAW ROATATION MOTION
		set_deg_inc(190.0,0.0,1,1,5,JAWROT);  //Send JAW ROTATION to extreme position using incremental motion algorithm
		delay (200);
		set_deg_inc(0.0,190.0,0,1,5,JAWROT);  //Send JAW ROTATION to extreme position using incremental motion algorithm
		delay (200);
		set_deg_abs(33, JAWROT);  //Return to safe hold
		delay (200);

 //ARM ROATATION MOTION
	   set_deg_inc(190.0,0.0,1,1,10,ARMROT);  //Send ARM ROTATION to extreme position using incremental motion algorithm
	   delay (200);
	   set_deg_inc(0.0,190.0,0,1,10,ARMROT);  //Send ARM ROTATION to extreme position using incremental motion algorithm
	   delay (200);
	   set_deg_abs(92, ARMROT);  //Return to safe hold
	   delay (200);

//ARM EXTENSION MOTION
	    set_deg_inc(145.0,30.0,1,1,8,ARMEXT);  //Send ARM to extreme position using incremental motion algorithm
	    delay (200);
	    set_deg_inc(30.0,145.0,0,1,8 ,ARMEXT);  //Send ARM to extreme position using incremental motion algorithm, this second step is used to prevent arm falling over apex of motion
	    delay (200);
	    set_deg_inc(3.0,30.0,0,.5,11,ARMEXT);  //Send ARM to extreme position using incremental motion algorithm
	    delay (200);
		set_deg_abs(30, ARMEXT);  //Return to safe hold
		delay (200);

		delay(1000); //Wait before return to top of cycle

}
