This folder contains an update of the design for the 2017 Embedded World demo created by UC Irvine.
The sample projects in this folder have been modified to match the hardware.
In addition, the SF2_GNU_SC4_interrupt_blink and SF2_GNU_SC4_pwm_slow_blink projects have been
further modified to support Semihosting as described in the SoftConsole 4.0 Release notes.

Tim McCarthy
February 14, 2017