Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release Libero SoC v11.8 SP1 (Version 11.8.1.12)

Date    :    Thu Nov 30 18:24:29 2017
Project :    C:\Users\Hiperwall\Desktop\Servo-arm3 - Copy
