Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v11.7 SP2 (Version 11.7.2.2)

Date    :    Mon Feb 13 22:12:21 2017
Project :    D:\Microsemiprj\UC_Irvine\PWM_6ch_16b_Creative_2_13_17\PWM_6ch_16b_Creative_2_13
