This folder contains the most recent Libero and SoftConsole projects for the Embedded World robotic arm demo based on 
NewProject_servo_arm2.zip which was downloaded from the Calit2 transfer system.  The following changes were made to the project:
1. The Libero SoC project was renamed Servo-arm2 (the project was previously named PWM_8ch_16b_Creative).
2. The SoftConsole project was renamed servoarm  (the project was originally named SF2_GNU_SC4_pwm_slow_blink).

No changes were made to the Libero project or SoftConsole project other than renaming the projects.

Tim McCarthy
March 6, 2017

This folder contains an update of the design for the 2017 Embedded World demo created by UC Irvine.
The sample projects in this folder have been modified to match the hardware.
In addition, the SF2_GNU_SC4_interrupt_blink and SF2_GNU_SC4_pwm_slow_blink projects have been
further modified to support Semihosting as described in the SoftConsole 4.0 Release notes.

Tim McCarthy
February 14, 2017

